
## 🚀 Skills
- **Languages:** Swift, Kotlin, Java
- **Frameworks:** SwiftUI, Android SDK, React Native
- **Tools:** Xcode, Android Studio, Git, Firebase
- **Design:** Figma, Adobe XD

## 📊 Coding Activity
![Rajwant's Coding Activity](https://github-readme-stats.vercel.app/api/wakatime?username=rajwantkaur27&layout=compact)


## 🌱 Currently Learning
- Machine Learning for mobile
- Advanced UI/UX design principles
- AR/VR development for mobile platforms

## 💬 Let's Connect
- [LinkedIn](www.linkedin.com/in/rajwant-sandhu-64611a2b3)

